# vlcLEDtimer
Small windows Tool to display the remaining playtime of a VLC player as led display.

Created at a Event as helpful tool running on the video guys screen to see upcoming end of Video or Song.

Tool connect via TCP to VLC and display remaining playtime and play status of player so info PC can be different from playing PC. We also put it on the laptop of the stage manager to give him a rough info about time left.

# Screenshots
![Configuration](https://raw.githubusercontent.com/solariz/vlcLEDtimer/master/screenshots/settings.png)
![Running Timer](https://raw.githubusercontent.com/solariz/vlcLEDtimer/master/screenshots/countdown.png)


# LICENSE
Feel free to use, only the used Icons are by YOYO for private usage only. So no resale or commercial bundling.

If you add change or improve things please be nice and push it back.

Thanks

